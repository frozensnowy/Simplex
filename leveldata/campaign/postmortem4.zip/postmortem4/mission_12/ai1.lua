aitrace("CPU: LOADING MISSION 12 PLAYER 1")
-- this function is usually called after loading default.lua
setLevelOfDifficulty(2)
print("geeeeeee " .. getLevelOfDifficulty())
dofilepath("data:ai/default.lua")
